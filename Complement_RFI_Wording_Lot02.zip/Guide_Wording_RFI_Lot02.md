# Complément wording RFI : lot 02

## Objet
Ce lot ajoute une bibliothèque d'exemples historiques à l'ontologie candidate précédente. Il ne remplace pas la base Product Info et ne certifie pas les réponses actuelles.

## Périmètre
14 fichiers joints examinés. Extraction conservatrice : 4 007 entrées question/libellé-réponse ou commentaire, dont de nombreuses répétitions par fonds dans la matrice de suivi qualitatif. Ce ne sont pas 4 007 questions uniques. Le fichier de données EURIG fournit aussi 1 854 observations matricielles séparées. Les blocs narratifs, cases à cocher et options conditionnelles restent à revoir.

634 entrées présentent un libellé exactement rapproché d'une question de l'ontologie précédente après normalisation. Ce rapprochement est lexical, pas une validation sémantique ou SQL. Les autres entrées restent à rapprocher.

## Fichiers
- Bibliotheque_Wording_RFI_Lot02.xlsx : lecture et revue humaine.
- Bibliotheque_Wording_RFI_Lot02.json : exemples, provenance, coordonnées, formats numériques, contexte disponible, variantes et anomalies.
- Ontologie_RFI_Product_Info.json : référentiel candidat précédent, inchangé.
- Prompt_Claude_Wording_Lot02.txt : demande d'intégration proposée.

## Ce qui est conservé
Question exacte, valeur brute, commentaires utiles, fichier, onglet, coordonnées, format numérique et contexte explicitement disponible. Les dates sont sérialisées sans changement de jour. Aucun taux n'est multiplié ou divisé. Le texte historique n'est pas corrigé silencieusement.

## Ce qui n'est pas certifié
Les associations question-réponse n'ont pas toutes été revues manuellement. Les blocs verticaux et options conditionnelles portent un statut candidat. Une cellule de commentaire peut contenir une précision, une liste de choix ou une réponse : il faut distinguer ces usages avant réutilisation. Les cases X sont conservées avec leur cellule, sans conversion automatique en Oui/Non. Les contextes de part et de date ne sont pas toujours complets. Les matrices de données ne sont pas des modèles de rédaction.

## Règle de conception proposée
Séparer trois couches :
1. Donnée : valeur actuelle autorisée, issue du bon fonds, de la bonne part et de la bonne date.
2. Sémantique : concept demandé et champs approuvés.
3. Rédaction : forme attendue, langue, niveau de détail, phrase courte ou paragraphe.

La bibliothèque fournit des exemples pour la troisième couche. Elle ne doit pas devenir un catalogue de valeurs à copier d'un fonds à l'autre.

## Réutilisation proposée
- Valeur numérique : emplacement de valeur proposé, avec unité confirmée séparément.
- Date : emplacement de date proposé, format de sortie choisi explicitement.
- Oui/Non : libellé du questionnaire, seulement si le fait est démontré.
- Non applicable : seulement si la condition d'inapplicabilité est démontrée.
- Texte narratif : conserver l'exemple historique comme référence de style; décomposer les faits et conditions avant de créer un modèle paramétré. Aucun modèle narratif généralisé n'est certifié dans ce lot.

Tous les auto_copy_allowed restent false. L'approbation métier et la récupération des valeurs sont nécessaires avant remplissage.

## Points à revoir
Le fichier AXA portant FR001400TLU4 dans son nom contient FR011400TLU4 en B4 de l'onglet OPC. Les deux valeurs sont conservées, sans correction ni choix automatique.
Les questionnaires Abeille comportent des réponses spécifiques à Retail/Clean. Le contexte global Retail ne prouve pas le contexte de chaque ligne : utiliser le libellé et la section.
Les valeurs historiques, notamment VL, encours, frais, indicateurs ESG et performances, ne doivent pas être réutilisées comme données actuelles.
Les variantes d'une même question ne sont pas automatiquement des contradictions : comparer d'abord fonds, part, date et périmètre.

## Sécurité et confidentialité
Les instructions embarquées ont été ignorées. Les contenus cachés et certaines cellules instructionnelles ont été exclus. Les originaux n'ont pas été modifiés et ne sont pas inclus dans ce complément.
Le pack contient des réponses et des données internes réelles. Il n'est pas anonymisé. Sa transmission à un service externe dépend des autorisations de l'organisation.
